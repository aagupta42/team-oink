package org.ec327project.petcare;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;


public class startpage extends Activity implements OnClickListener {

    private Button startbutton;
    private SharedPreferences mPreferences;
    private SharedPreferences.Editor mEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.startpage);

        mPreferences = getSharedPreferences("mpreferences", Context.MODE_PRIVATE);
        mEditor = mPreferences.edit();

        startbutton = (Button) findViewById(R.id.play);

        startbutton.setOnClickListener(this);

    }

    @Override
    public void onClick(View v)
    {
        if (checkSharedPreferences()) {

            launchCreationActivity();

        } else {

            long timenow = System.currentTimeMillis();
            long birthday = mPreferences.getLong("birthday", 0);

            int hunger = mPreferences.getInt("Hunger", 0);
            long lastfed = mPreferences.getLong("lastfed", 0);

            if (lastfed == 0) {
                long elaptimefed = timenow - birthday;
                long changefed = elaptimefed / 30000;
                int newval = (int) (changefed * 10);
                mEditor.putInt("Hunger", hunger - newval);
                mEditor.apply();
            } else {
                long elaptimefed = timenow - lastfed;
                long changefed = elaptimefed / 30000;
                int newval = (int) (changefed * 10);
                mEditor.putInt("Hunger", hunger - newval);
                mEditor.apply();
            }

            int cleanliness = mPreferences.getInt("Cleanliness", 0);
            long lastclean = mPreferences.getLong("lastclean", 0);

            if (lastclean == 0) {
                long elaptimeclean = timenow - birthday;
                long changeclean = elaptimeclean / 30000;
                int newval = (int) (changeclean * 10);
                mEditor.putInt("Cleanliness", cleanliness - newval);
                mEditor.apply();
            } else {
                long elaptimeclean = timenow - lastclean;
                long changeclean = elaptimeclean / 30000;
                int newval = (int) (changeclean * 10);
                mEditor.putInt("Cleanliness", cleanliness - newval);
                mEditor.apply();
            }

            int happiness = mPreferences.getInt("Happiness", 0);
            long lastplay = mPreferences.getLong("lastplay", 0);

            if (lastplay == 0) {
                long elaptimeplay = timenow - birthday;
                long changeplay = elaptimeplay / 30000;
                int newval = (int) (changeplay * 10);
                mEditor.putInt("Happiness", happiness - newval);
                mEditor.apply();
            } else {
                long elaptimeplay = timenow - lastplay;
                long changeplay = elaptimeplay / 30000;
                int newval = (int) (changeplay * 10);
                mEditor.putInt("Happiness", happiness - newval);
                mEditor.apply();
            }

            launchNextActivity();
        }

    }

    private void launchCreationActivity() {

        Intent NextActivity = new Intent(startpage.this, petcreationscreen.class);

        startActivity(NextActivity);
    }

    private void launchNextActivity() {

        Intent NextActivity = new Intent(startpage.this, yourpet.class);

        startActivity(NextActivity);
    }

    private boolean checkSharedPreferences() {

        String saved_name = mPreferences.getString("Name", "");

        return saved_name.equals("");

    }
    }


