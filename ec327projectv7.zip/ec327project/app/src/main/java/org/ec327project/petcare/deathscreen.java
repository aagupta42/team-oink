package org.ec327project.petcare;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.content.SharedPreferences.Editor;
import android.content.SharedPreferences;

public class deathscreen extends Activity implements OnClickListener{

    private Button endgame;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.deathscreen);

        endgame = (Button) findViewById(R.id.restart);

        endgame.setOnClickListener(this);
    }

    @Override
    public void onClick(View v)
    {

        launchNextActivity();

    }

    private void launchNextActivity()
    {

        Intent NextActivity = new Intent(deathscreen.this, startpage.class);

        startActivity(NextActivity);
    }

}

