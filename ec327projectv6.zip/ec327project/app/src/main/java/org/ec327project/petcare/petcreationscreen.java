package org.ec327project.petcare;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Context;

public class petcreationscreen extends Activity implements OnClickListener {

    public static final String TAG_NAME = "tag";

    private EditText et;

    private Button createPet;

    private SharedPreferences mPreferences;
    private SharedPreferences.Editor mEditor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.petcreationscreen);

        et = (EditText) findViewById(R.id.choosename);
        createPet = (Button) findViewById(R.id.create);

        mPreferences = getSharedPreferences("mypreferences", Context.MODE_PRIVATE);
        mEditor = mPreferences.edit();

        createPet.setOnClickListener(this);

    }

    @Override
    public void onClick(View v)
    {
        String name = et.getText().toString();

        if(name.equals(""))
        {
            Toast.makeText(petcreationscreen.this, "Oops! Make sure to give me a name.", Toast.LENGTH_LONG).show();
            return;
        }
        else {

            long birthday = System.currentTimeMillis();

            mEditor.putInt("Hunger", 100);
            mEditor.putInt("Happiness", 100);
            mEditor.putInt("Cleanliness", 100);
            mEditor.putString("Name", name);
            mEditor.putLong("lastfed", 0);
            mEditor.putLong("lastclean", 0);
            mEditor.putLong("lastplay", 0);
            mEditor.putLong("birthday", birthday);
            mEditor.apply();

            launchNextActivity(name);

        }

    }

    private void launchNextActivity(String name)
    {

        Intent nextActivity = new Intent(petcreationscreen.this, yourpet.class);

        nextActivity.putExtra(TAG_NAME, name);

        startActivity(nextActivity);
    }

}
