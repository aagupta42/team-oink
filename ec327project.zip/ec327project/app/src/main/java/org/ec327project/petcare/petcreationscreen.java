package org.ec327project.petcare;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Context;

public class petcreationscreen extends Activity implements OnClickListener {

    public static final String TAG_NAME = "tag";

    private EditText et;

    private Button createPet;

    // SharedPreferences settings = getSharedPreferences("mysettings", Context.MODE_PRIVATE);
    // SharedPreferences.Editor editor = settings.edit();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.petcreationscreen);

        et = (EditText) findViewById(R.id.choosename);
        createPet = (Button) findViewById(R.id.create);

        createPet.setOnClickListener(this);

    }

    @Override
    public void onClick(View v)
    {
        String name = et.getText().toString();

        if(name.equals(""))
        {
            Toast.makeText(petcreationscreen.this, "Oops! Make sure to give me a name.", Toast.LENGTH_LONG).show();
            return;
        }
        else {

            /*editor.putInt("Hunger", 100);
            editor.putInt("Happiness", 100);
            editor.putInt("Cleanliness", 100);
            editor.putString("Name", name);
            editor.apply(); */
            launchNextActivity(name);

        }

    }

    private void launchNextActivity(String name)
    {

        Intent nextActivity = new Intent(petcreationscreen.this, yourpet.class);

        nextActivity.putExtra(TAG_NAME,name);

        startActivity(nextActivity);
    }

}
