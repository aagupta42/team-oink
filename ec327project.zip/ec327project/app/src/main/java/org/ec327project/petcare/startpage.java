package org.ec327project.petcare;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.content.SharedPreferences;

public class startpage extends Activity implements OnClickListener {

    private Button startbutton;
    SharedPreferences settings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.startpage);

        startbutton = (Button) findViewById(R.id.play);

        startbutton.setOnClickListener(this);

    }

    @Override
    public void onClick(View v)
    {
        if (checkSharedPreferences()) {

            launchCreationActivity();

        } else {

            launchNextActivity();

        }
    }

    private void launchCreationActivity() {

        Intent NextActivity = new Intent(startpage.this, petcreationscreen.class);

        startActivity(NextActivity);
    }

    private void launchNextActivity() {

        Intent NextActivity = new Intent(startpage.this, yourpet.class);

        startActivity(NextActivity);
    }

    private boolean checkSharedPreferences() {

        String saved_name = settings.getString("Name","default");

        return saved_name.equals("");

    }
    }


