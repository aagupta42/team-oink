package org.ec327project.petcare;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;
import android.widget.ProgressBar;

public class yourpet extends AppCompatActivity {

    ImageButton funbutton;
    ImageButton hygienebutton;
    ImageButton hungerbutton;

    ProgressBar hungerProgressbar;
    ProgressBar hygieneProgressbar;
    ProgressBar funProgressbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.yourpet);

        funbutton = (ImageButton) findViewById(R.id.fun_button);
        hygienebutton = (ImageButton) findViewById(R.id.hygiene_button);
        hungerbutton = (ImageButton) findViewById(R.id.hunger_button);

        hungerProgressbar = (ProgressBar) findViewById(R.id.hunger);
        hygieneProgressbar = (ProgressBar) findViewById(R.id.hygiene);
        funProgressbar = (ProgressBar) findViewById(R.id.fun);

        funbutton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (funProgressbar.getProgress() == 100) {
                    Toast.makeText(yourpet.this, "I don't want to play!", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(yourpet.this, "Yay!", Toast.LENGTH_LONG).show();
                    funProgressbar.incrementProgressBy(10);
                }
            }
        });

        hygienebutton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (hygieneProgressbar.getProgress() == 100) {
                    Toast.makeText(yourpet.this,"No, I don't want a bath!", Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(yourpet.this, "ahhhh that's better", Toast.LENGTH_LONG).show();
                    hygieneProgressbar.incrementProgressBy(10);
                }

            }
        });

        hungerbutton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (hungerProgressbar.getProgress() == 100) {
                    Toast.makeText(yourpet.this, "I'm full!", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(yourpet.this, "Yum!", Toast.LENGTH_LONG).show();
                    hungerProgressbar.incrementProgressBy(10);
                }
            }
        });
    }


}
