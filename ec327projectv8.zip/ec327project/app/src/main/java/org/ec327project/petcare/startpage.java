package org.ec327project.petcare;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;
import android.media.MediaPlayer;



public class startpage extends Activity implements OnClickListener {

    private Button startbutton;
    private SharedPreferences mPreferences;
    private SharedPreferences.Editor mEditor;
    MediaPlayer mysong;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.startpage);

        mPreferences = getSharedPreferences("set", Context.MODE_PRIVATE);
        mEditor = mPreferences.edit();

        startbutton = (Button) findViewById(R.id.play);

        startbutton.setOnClickListener(this);

        mysong = MediaPlayer.create(startpage.this, R.raw.ec327music);
        mysong.start();

    }

    @Override
    public void onClick(View v)
    {
        if (checkSharedPreferences()) {

            launchCreationActivity();

        } else {

            long timenow = System.currentTimeMillis();
            long birthday = mPreferences.getLong("birthday", 0);
            long lastscreen = mPreferences.getLong("lastscreen",0);

            int hunger = mPreferences.getInt("Hunger", 0);
            long lastfed = mPreferences.getLong("lastfed", 0);
            boolean fed = mPreferences.getBoolean("fed",false);

            if (fed==false) {
                long elaptimefed = timenow - lastscreen;
                long changefed = elaptimefed / 30000;
                int newval = (int) (changefed * 10);
                mEditor.putInt("Hunger", hunger - newval);
                mEditor.apply();
            } else if (fed==true){
                long elaptimefed = timenow - lastfed;
                long changefed = elaptimefed / 30000;
                int newval = (int) (changefed * 10);
                mEditor.putInt("Hunger", hunger - newval);
                mEditor.apply();
            }

            int cleanliness = mPreferences.getInt("Cleanliness", 0);
            long lastclean = mPreferences.getLong("lastclean", 0);
            boolean clean = mPreferences.getBoolean("clean",false);

            if (clean==false) {
                long elaptimeclean = timenow - lastscreen;
                long changeclean = elaptimeclean / 30000;
                int newval = (int) (changeclean * 10);
                mEditor.putInt("Cleanliness", cleanliness - newval);
                mEditor.apply();
            } else if (clean==true) {
                long elaptimeclean = timenow - lastclean;
                long changeclean = elaptimeclean / 30000;
                int newval = (int) (changeclean * 10);
                mEditor.putInt("Cleanliness", cleanliness - newval);
                mEditor.apply();
            }

            int happiness = mPreferences.getInt("Happiness", 0);
            long lastplay = mPreferences.getLong("lastplay", 0);
            boolean play = mPreferences.getBoolean("play",false);

            if (play == false) {
                long elaptimeplay = timenow - lastscreen;
                long changeplay = elaptimeplay / 30000;
                int newval = (int) (changeplay * 10);
                mEditor.putInt("Happiness", happiness - newval);
                mEditor.apply();
            } else if (play==true){
                long elaptimeplay = timenow - lastplay;
                long changeplay = elaptimeplay / 30000;
                int newval = (int) (changeplay * 10);
                mEditor.putInt("Happiness", happiness - newval);
                mEditor.apply();
            }


            int curr_hunger = mPreferences.getInt("Hunger", 0);
            int curr_cleanliness = mPreferences.getInt("Cleanliness", 0);
            int curr_happiness = mPreferences.getInt("Happiness", 0);

            if ((curr_hunger < 0) || (curr_hunger == 0)) {
                launchDeathActivity();
            } else if ((curr_cleanliness < 0) || (curr_cleanliness == 0)){
                launchDeathActivity();
            } else if ((curr_happiness < 0) || (curr_happiness == 0)){
                launchDeathActivity();
            } else {
                mEditor.putBoolean("play", false);
                mEditor.putBoolean("clean", false);
                mEditor.putBoolean("fed", false);
                mEditor.apply();
                launchNextActivity();
            }

        }

    }

    /* @Override
    protected void OnPause(){
        super.onPause();
        mysong.release();
        finish();
    } */

    private void launchCreationActivity() {

        Intent NextActivity = new Intent(startpage.this, petcreationscreen.class);

        startActivity(NextActivity);
    }

    private void launchNextActivity() {

        Intent NextActivity = new Intent(startpage.this, yourpet.class);

        startActivity(NextActivity);
    }

    private void launchDeathActivity() {

        Intent NextActivity = new Intent(startpage.this, MainActivity.class);

        startActivity(NextActivity);
    }

    private boolean checkSharedPreferences() {

        String saved_name = mPreferences.getString("Name", "");

        return saved_name.equals("");

    }

    }


