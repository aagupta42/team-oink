package org.ec327project.petcare;

import android.app.Activity;
import android.content.Context;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.content.SharedPreferences.Editor;
import android.content.SharedPreferences;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends Activity implements OnClickListener{

        private Button endgame;
        private SharedPreferences mPreferences;
        private SharedPreferences.Editor mEditor;
        // globally
        TextView petlife;
        TextView highscore;
        MediaPlayer mysong;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.deathscreen);

        mPreferences = getSharedPreferences("set", Context.MODE_PRIVATE);
        mEditor = mPreferences.edit();

        endgame = (Button) findViewById(R.id.restart);

        endgame.setOnClickListener(this);

        int saved_highscore = mPreferences.getInt("highscore", 0);
        long birthday = mPreferences.getLong("birthday", 0);
        long curr_time = System.currentTimeMillis();
        int lifetime = (int) (curr_time - birthday);
        lifetime = (int) (lifetime / 30000);
        // String life = Integer.toString(lifetime);

        petlife  = (TextView)findViewById(R.id.current_pet_life);
        String curr_life = getResources().getString(R.string.current_life, lifetime);
        petlife.setText(curr_life);

        if (saved_highscore >= lifetime){
            highscore = (TextView)findViewById(R.id.highscore);
            String highscoretext = getResources().getString(R.string.highscore, saved_highscore);
            highscore.setText(highscoretext);

        } else {
            highscore = (TextView)findViewById(R.id.highscore);
            String highscoretext = getResources().getString(R.string.highscore, lifetime);
            highscore.setText(highscoretext);
            mEditor.putInt("highscore", lifetime);
            mEditor.apply();
        }

    }

    @Override
    public void onClick(View v)
    {
        int highscore = mPreferences.getInt("highscore", 0);
        mEditor.clear();
        mEditor.putInt("highscore", highscore);
        mEditor.apply();
        launchNextActivity();

    }

    private void launchNextActivity()
    {

        Intent NextActivity = new Intent(MainActivity.this, startpage.class);

        startActivity(NextActivity);
    }


}


