package org.ec327project.petcare;

import android.app.Activity;
import android.os.Bundle;

public class test extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);
    }
}


