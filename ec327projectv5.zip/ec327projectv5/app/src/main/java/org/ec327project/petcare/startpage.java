package org.ec327project.petcare;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;
import android.content.Context;

public class startpage extends Activity implements OnClickListener {

    private Button startbutton;
    private SharedPreferences mPreferences;
    private SharedPreferences.Editor mEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.startpage);

        mPreferences = getSharedPreferences("mypreferences", Context.MODE_PRIVATE);
        mEditor = mPreferences.edit();


        startbutton = (Button) findViewById(R.id.play);

        startbutton.setOnClickListener(this);

    }

    @Override
    public void onClick(View v)
    {
        if (checkSharedPreferences()) {

            launchCreationActivity();

        } else {

            long timenow = System.currentTimeMillis();
            long birthday = mPreferences.getLong("birthday",0);

            int hunger = mPreferences.getInt("Hunger",0);

            long lastfed = mPreferences.getLong("lastfed",0);

            if (lastfed == 0){
                long elaptimefed = timenow - birthday;
                long changefed = elaptimefed/30000;
                int newval = (int)(changefed * 10);
                mEditor.putInt("Hunger",hunger-newval);
                mEditor.apply();
            }
            else {
                long elaptimefed = timenow - lastfed;
                long changefed = elaptimefed/30000;
                int newval = (int)(changefed * 10);
                mEditor.putInt("Hunger",hunger-newval);
                mEditor.apply();
            }

            launchNextActivity();

        }
    }

    private void launchCreationActivity() {

        Intent NextActivity = new Intent(startpage.this, petcreationscreen.class);

        startActivity(NextActivity);
    }

    private void launchNextActivity() {

        Intent NextActivity = new Intent(startpage.this, yourpet.class);

        startActivity(NextActivity);
    }

    private boolean checkSharedPreferences() {

        String saved_name = mPreferences.getString("Name","");

        return saved_name.equals("");

    }
    }


