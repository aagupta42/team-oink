package org.ec327project.petcare;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;
import android.widget.ProgressBar;
import android.content.SharedPreferences;
import android.content.Context;

public class yourpet extends AppCompatActivity {

    ImageButton funbutton;
    ImageButton hygienebutton;
    ImageButton hungerbutton;

    ProgressBar hungerProgressbar;
    ProgressBar hygieneProgressbar;
    ProgressBar funProgressbar;

    private SharedPreferences mPreferences;
    private SharedPreferences.Editor mEditor;

    MediaPlayer mysong;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.yourpet);

        mysong = MediaPlayer.create(yourpet.this, R.raw.ec327music);
        mysong.start();

        funbutton = (ImageButton) findViewById(R.id.fun_button);
        hygienebutton = (ImageButton) findViewById(R.id.hygiene_button);
        hungerbutton = (ImageButton) findViewById(R.id.hunger_button);

        hungerProgressbar = (ProgressBar) findViewById(R.id.hunger);
        hygieneProgressbar = (ProgressBar) findViewById(R.id.hygiene);
        funProgressbar = (ProgressBar) findViewById(R.id.fun);

        mPreferences = getSharedPreferences("set", Context.MODE_PRIVATE);
        mEditor = mPreferences.edit();

        long lastscreen = System.currentTimeMillis();
        mEditor.putLong("lastscreen",lastscreen);
        mEditor.apply();

        int hunger = mPreferences.getInt("Hunger", 0);
        hungerProgressbar.setProgress(hunger);

        int happiness = mPreferences.getInt("Happiness", 0);
        funProgressbar.setProgress(happiness);

        int clean = mPreferences.getInt("Cleanliness", 0);
        hygieneProgressbar.setProgress(clean);

        // OnClickListeners update progress bars and boolean activity markers
        // Updates SharedPreferences for pet
        funbutton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                long lastplay = System.currentTimeMillis();
                mEditor.putLong("lastplay", lastplay);
                mEditor.putBoolean("play", true);
                mEditor.apply();
                if (funProgressbar.getProgress() == 100) {
                    Toast.makeText(yourpet.this, "I don't want to play!", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(yourpet.this, "Yay!", Toast.LENGTH_LONG).show();
                    funProgressbar.incrementProgressBy(10);
                    int happiness = mPreferences.getInt("Happiness", 0);
                    mEditor.putInt("Happiness", happiness + 10);
                    mEditor.apply();
                }
            }
        });

        hygienebutton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                long lastclean = System.currentTimeMillis();
                mEditor.putLong("lastclean", lastclean);
                mEditor.putBoolean("clean", true);
                mEditor.apply();
                if (hygieneProgressbar.getProgress() == 100) {
                    Toast.makeText(yourpet.this,"No, I don't want a bath!", Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(yourpet.this, "ahhhh that's better", Toast.LENGTH_LONG).show();
                    hygieneProgressbar.incrementProgressBy(10);
                    int cleanliness = mPreferences.getInt("Cleanliness", 0);
                    mEditor.putInt("Cleanliness", cleanliness + 10);
                    mEditor.apply();
                }

            }
        });

        hungerbutton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                long lastfed = System.currentTimeMillis();
                mEditor.putLong("lastfed", lastfed);
                mEditor.putBoolean("fed", true);
                mEditor.apply();
                if (hungerProgressbar.getProgress() == 100) {
                    Toast.makeText(yourpet.this, "I'm full!", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(yourpet.this, "Yum!", Toast.LENGTH_LONG).show();
                    hungerProgressbar.incrementProgressBy(10);

                    int hunger = mPreferences.getInt("Hunger", 0);
                    mEditor.putInt("Hunger", hunger + 10);
                    mEditor.apply();
                }
            }
        });
    }


}
