package org.ec327project.petcare;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.content.SharedPreferences;
import android.media.MediaPlayer;



public class startpage extends Activity implements OnClickListener {

    private Button startbutton;
    private SharedPreferences mPreferences;
    private SharedPreferences.Editor mEditor;
    MediaPlayer mysong;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.startpage);

        mPreferences = getSharedPreferences("set", Context.MODE_PRIVATE);
        mEditor = mPreferences.edit();

        startbutton = (Button) findViewById(R.id.play);

        startbutton.setOnClickListener(this);

        mysong = MediaPlayer.create(startpage.this, R.raw.startsong);
        mysong.start();

    }

    @Override
    public void onClick(View v)
    { mysong.release();
        // checking if pet exists; if so, go straight to main activity
        if (checkSharedPreferences()) {
            launchCreationActivity();

        // update necessary values based on time elapsed from either last time interacted or last time app opened
        } else {
            int demo_time = 30000; // demo testing interval
            int real_time = 10800000; // real testing interval
            long timenow = System.currentTimeMillis();
            long birthday = mPreferences.getLong("birthday", 0);
            long lastscreen = mPreferences.getLong("lastscreen",0);

            int hunger = mPreferences.getInt("Hunger", 0);
            long lastfed = mPreferences.getLong("lastfed", 0);
            boolean fed = mPreferences.getBoolean("fed",false);

            /* This next section checks for if user interacted with pet last time they opened the app
               If they did, then calculated updated values based on that saved time. Otherwise update
               based on last time app was opened to prevent "double" decrementing of attributes
             */
            if (fed==false) {
                long elaptimefed = timenow - lastscreen;
                long changefed = elaptimefed / demo_time;
                // long changefed = elaptimefed / real_time; use this line for real life application
                int newval = (int) (changefed * 10);
                mEditor.putInt("Hunger", hunger - newval);
                mEditor.apply();
                // otherwise,
            } else if (fed==true){
                long elaptimefed = timenow - lastfed;
                long changefed = elaptimefed / demo_time;
                // long changefed = elaptimefed / real_time; use this line for real life application
                int newval = (int) (changefed * 10);
                mEditor.putInt("Hunger", hunger - newval);
                mEditor.apply();
            }

            int cleanliness = mPreferences.getInt("Cleanliness", 0);
            long lastclean = mPreferences.getLong("lastclean", 0);
            boolean clean = mPreferences.getBoolean("clean",false);

            if (clean==false) {
                long elaptimeclean = timenow - lastscreen;
                long changeclean = elaptimeclean / demo_time;
                // long changefed = elaptimefed / real_time; use this line for real life application
                int newval = (int) (changeclean * 10);
                mEditor.putInt("Cleanliness", cleanliness - newval);
                mEditor.apply();
            } else if (clean==true) {
                long elaptimeclean = timenow - lastclean;
                long changeclean = elaptimeclean / demo_time;
                // long changefed = elaptimefed / real_time; use this line for real life application
                int newval = (int) (changeclean * 10);
                mEditor.putInt("Cleanliness", cleanliness - newval);
                mEditor.apply();
            }

            int happiness = mPreferences.getInt("Happiness", 0);
            long lastplay = mPreferences.getLong("lastplay", 0);
            boolean play = mPreferences.getBoolean("play",false);

            if (play == false) {
                long elaptimeplay = timenow - lastscreen;
                long changeplay = elaptimeplay / demo_time;
                int newval = (int) (changeplay * 10);
                mEditor.putInt("Happiness", happiness - newval);
                mEditor.apply();
            } else if (play==true){
                long elaptimeplay = timenow - lastplay;
                long changeplay = elaptimeplay / demo_time;
                int newval = (int) (changeplay * 10);
                mEditor.putInt("Happiness", happiness - newval);
                mEditor.apply();
            }

            // Checking for death:
            // Obtaining SharedPreferences values: if any are zero, pet dies!
            int curr_hunger = mPreferences.getInt("Hunger", 0);
            int curr_cleanliness = mPreferences.getInt("Cleanliness", 0);
            int curr_happiness = mPreferences.getInt("Happiness", 0);

            if ((curr_hunger < 0) || (curr_hunger == 0)) {
                launchDeathActivity();
            } else if ((curr_cleanliness < 0) || (curr_cleanliness == 0)){
                launchDeathActivity();
            } else if ((curr_happiness < 0) || (curr_happiness == 0)){
                launchDeathActivity();
            } else {
                // reset activity boolean values
                mEditor.putBoolean("play", false);
                mEditor.putBoolean("clean", false);
                mEditor.putBoolean("fed", false);
                mEditor.apply();
                launchNextActivity();
            }

        }

    }

    private void launchCreationActivity() {

        // if no pet has been created
        Intent NextActivity = new Intent(startpage.this, petcreationscreen.class);

        startActivity(NextActivity);
    }

    private void launchNextActivity() {

        // main pet activity
        Intent NextActivity = new Intent(startpage.this, yourpet.class);

        startActivity(NextActivity);
    }

    private void launchDeathActivity() {

        // if pet dies
        Intent NextActivity = new Intent(startpage.this, MainActivity.class);

        startActivity(NextActivity);
    }

    private boolean checkSharedPreferences() {

        // checking for a saved pet name, which indicates a created pet
        String saved_name = mPreferences.getString("Name", "");

        return saved_name.equals("");

    }

    }


