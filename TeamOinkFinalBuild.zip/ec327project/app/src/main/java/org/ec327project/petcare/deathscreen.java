package org.ec327project.petcare;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.content.SharedPreferences.Editor;
import android.content.SharedPreferences;

public class deathscreen extends Activity{
/*
    private Button endgame;
    private SharedPreferences mPreferences;
    private SharedPreferences.Editor mEditor;
*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.deathscreen);

        //mPreferences = getSharedPreferences("mysett", Context.MODE_PRIVATE);
        //mEditor = mPreferences.edit();

        //endgame = (Button) findViewById(R.id.restart);

        //endgame.setOnClickListener(this);
    }
/*
    @Override
    public void onClick(View v)
    {
       mEditor.clear();
       mEditor.apply();
       launchNextActivity();

    }

    private void launchNextActivity()
    {

        Intent NextActivity = new Intent(deathscreen.this, startpage.class);

        startActivity(NextActivity);
    }
    */

}

